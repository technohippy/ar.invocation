
##### Changes Proposed:

##### Fixes:

##### Checklist:

- [ ] Tested on WebARonARCore
- [ ] Tested on WebARonARKit
- [ ] I've read CONTRIBUTING.md and signed the CLA (required)
- [ ] This PR does not contain built changes in `dist/\*` (required)
- [ ] This PR only contains one commit (required)
