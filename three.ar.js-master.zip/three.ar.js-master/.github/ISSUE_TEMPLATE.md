##### Description:

Please describe your issue or feature request in detail.
Code and screenshots will help us diagnose the issue.

##### Additional Information:

* three.ar.js version:
* three.js version:
* Browser:

- [ ] WebARonARKit (iOS)
- [ ] WebARonARCore (Android)
- [ ] WebARonTango (Android)
- [ ] All
- [ ] Other (please specify)
